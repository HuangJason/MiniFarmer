//
//  InvitedCode.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/14.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import "BaseModel.h"

@interface InvitedCode : BaseModel

@end
