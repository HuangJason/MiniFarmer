//
//  UIButton+MTButtonCheckMarkAnimation.h
//  AssetDemo
//
//  Created by renqingyang on 15/6/23.
//  Copyright (c) 2015年 renqingyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (MTButtonCheckMarkAnimation)

- (void)mt_setImageWithAnimation:(UIImage *)image forState:(UIControlState)state;

@end
