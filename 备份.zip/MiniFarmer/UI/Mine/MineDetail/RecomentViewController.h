//
//  RecomentViewController.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/16.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import "MineBaseViewController.h"

@interface RecomentViewController : MineBaseViewController

@end
