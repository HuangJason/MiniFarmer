//
//  AboutViewController.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/17.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import "MineBaseViewController.h"

@interface AboutViewController : MineBaseViewController

@end
