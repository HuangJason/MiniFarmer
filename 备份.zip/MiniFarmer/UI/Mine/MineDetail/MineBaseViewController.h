//
//  MineBaseViewController.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/14.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import "BaseViewController.h"
//这个controller 是专门为了 我的使用的
#import "BaseViewController+Navigation.h"


@interface MineBaseViewController : BaseViewController

@end
