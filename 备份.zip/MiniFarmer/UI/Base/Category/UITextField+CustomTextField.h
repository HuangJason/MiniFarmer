//
//  UITextField+CustomTextField.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/17.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (CustomTextField)

-(void)setTextFieldLeftPaddingForWidth:(CGFloat)leftWidth;


@end
