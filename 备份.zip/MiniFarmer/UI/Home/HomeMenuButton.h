//
//  HomeMenuButton.h
//  MiniFarmer
//
//  Created by huangjiancheng on 15/11/8.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kMenuBtnImgWidth         51
#define kMenuBtnImgHeight        51
#define kMenuBtnSpace            12
#define kMenuBtnTitleHeight      23

@interface HomeMenuButton : UIButton

@end
