//
//  AnswersButton.h
//  MiniFarmer
//
//  Created by huangjiancheng on 15/10/29.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kAnsBtnImgWidth         15
#define kAnsBtnImgHeight        15
#define kAnsBtnSpace            4
#define kAnsBtnTitleHeight      19

@interface AnswersButton : UIButton

@end
