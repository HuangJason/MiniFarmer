//
//  QuestionDetailViewController.h
//  MiniFarmer
//
//  Created by huangjiancheng on 15/11/8.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface QuestionDetailViewController : BaseViewController

- (instancetype)initWithWtid:(NSString *)wtid;

@end
