//
//  RegisterViewController.h
//  MiniFarmer
//
//  Created by 尹新春 on 15/11/2.
//  Copyright © 2015年 enbs. All rights reserved.
//

#import "BaseViewController.h"

@interface RegisterViewController : BaseViewController

@end
