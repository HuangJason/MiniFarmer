//
//  SHJSONResponseSerializerData.h
//  baby
//
//  Created by lic on 15/1/8.
//  Copyright (c) 2015年 lic. All rights reserved.
//
//AFNetworking处理HTTP请求返回为非200（Failure Block）时获取body中json

#import "AFURLResponseSerialization.h"

@interface SHJSONResponseSerializerData : AFJSONResponseSerializer

@end
